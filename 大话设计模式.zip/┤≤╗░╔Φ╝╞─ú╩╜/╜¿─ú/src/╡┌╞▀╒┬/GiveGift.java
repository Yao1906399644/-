package ������;

public interface GiveGift
{
	void giveDolls();

	void giveFlowers();

	void giveChocolate();
}