package ��12��;

public class SubSystemOne
{
	public void methodOne()
	{
		System.out.println("��ϵͳ����1");
	}
}
class SubSystemTwo
{
	public void methodTwo()
	{
		System.out.println("��ϵͳ����2");
	}
}
class SubSystemThree
{
	public void methodThree()
	{
		System.out.println("��ϵͳ����3");
	}
}
class SubSystemFour
{
	public void methodFour()
	{
		System.out.println("��ϵͳ����4");
	}
}
//�����
class Facade
{
	SubSystemOne	one;
	SubSystemTwo	two;
	SubSystemThree	three;
	SubSystemFour	four;

	public Facade()
	{
		one = new SubSystemOne();
		two = new SubSystemTwo();
		three = new SubSystemThree();
		four = new SubSystemFour();
	}

	public void methodA()
	{
		System.out.println("������A");
		one.methodOne();
		two.methodTwo();
		four.methodFour();
	}

	public void methodB()
	{
		System.out.println("������B");
		two.methodTwo();
		three.methodThree();
	}
}