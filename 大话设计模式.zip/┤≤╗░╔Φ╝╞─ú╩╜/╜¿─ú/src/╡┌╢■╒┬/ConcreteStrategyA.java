package �ڶ���;

public class ConcreteStrategyA implements Strategy
{
	public void algorithmInterface()
	{
		System.out.println("�㷨Aʵ��");
	}
}
