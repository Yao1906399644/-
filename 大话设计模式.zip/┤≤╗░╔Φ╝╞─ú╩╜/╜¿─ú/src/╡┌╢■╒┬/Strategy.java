package �ڶ���;

public interface Strategy
{
	public void algorithmInterface();
}
