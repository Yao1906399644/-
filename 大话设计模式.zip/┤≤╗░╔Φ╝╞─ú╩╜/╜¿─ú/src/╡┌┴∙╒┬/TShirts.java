package ������;

public class TShirts extends Finery
{
	public void show()
	{
		super.show();
		System.out.println("��T��");
	}
}
class BigTrouser extends Finery
{
	public void show()
	{
		super.show();
		System.out.println("�����");
	}
}
class Sneakers extends Finery
{
	public void show()
	{
		super.show();
		System.out.println("����Ь");
	}
}
 class Suit extends Finery
{
	public void show()
	{
		super.show();
		System.out.println("��װ");
	}
}
 class Tie extends Finery
{
	public void show()
	{
		super.show();
		System.out.println("���");
	}
}
 class LeatherShoes extends Finery
{
	public void show()
	{
		super.show();
		System.out.println("ƤЬ");
	}
}